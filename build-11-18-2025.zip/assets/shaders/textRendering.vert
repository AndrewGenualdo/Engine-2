#version 330

layout (location = 0) in vec4 vertex; //<vec2 position, vec2 texture>
out vec2 TextureCoordinates;

uniform mat4 projection;

void main()
{
    gl_Position = projection * vec4(vertex.xy, 0.0, 1.0);
    TextureCoordinates = vertex.zw;

}